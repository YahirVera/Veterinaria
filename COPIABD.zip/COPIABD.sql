/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

CREATE DATABASE IF NOT EXISTS `petcompanion` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `petcompanion`;

DELIMITER //
CREATE PROCEDURE `ActualizarCliente`(
  IN cliente_id VARCHAR(8),
  IN nuevo_nombre VARCHAR(50),
  IN nuevo_apellido VARCHAR(50),
  IN nuevo_dni VARCHAR(50),
  IN nuevo_telefono VARCHAR(20),
  IN nuevo_email VARCHAR(50),
  IN nuevo_tipo VARCHAR(50)
)
BEGIN
  UPDATE Cliente
  SET nombre = nuevo_nombre,
      apellido = nuevo_apellido,
      dni = nuevo_dni,
      telefono = nuevo_telefono,
      email = nuevo_email,
      tipo = nuevo_tipo
  WHERE idcliente = cliente_id;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `ActualizarMascota`(
    IN p_idmascota VARCHAR(8),
    IN p_raza VARCHAR(50),
    IN p_fecha_nacimiento DATE,
    IN p_cliente_idcliente VARCHAR(8),
    IN p_sexo VARCHAR(50)
)
BEGIN
    UPDATE Mascota
    SET raza = p_raza, fecha_nacimiento = p_fecha_nacimiento,
        cliente_idcliente = p_cliente_idcliente, sexo = p_sexo
    WHERE idmascota = p_idmascota;
    SELECT 'Datos de mascota actualizados correctamente' AS mensaje;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `ActualizarProducto`(
    IN p_idproducto VARCHAR(8),
    IN p_nombre VARCHAR(50),
    IN p_descripcion VARCHAR(100),
    IN p_marca VARCHAR(50),
    IN p_precio DECIMAL(10, 2),
    IN p_stock INT
)
BEGIN
    UPDATE Producto
    SET nombre = p_nombre,
        descripcion = p_descripcion,
        marca = p_marca,
        precio = p_precio,
        stock = p_stock
    WHERE idproducto = p_idproducto;
END//
DELIMITER ;

CREATE TABLE IF NOT EXISTS `adopcion` (
  `idadopcion` varchar(8) NOT NULL,
  `idmascota` varchar(8) DEFAULT NULL,
  `idcliente` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`idadopcion`),
  KEY `idmascota` (`idmascota`),
  KEY `idcliente` (`idcliente`),
  CONSTRAINT `adopcion_ibfk_1` FOREIGN KEY (`idmascota`) REFERENCES `mascota` (`idmascota`),
  CONSTRAINT `adopcion_ibfk_2` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `adopcion` (`idadopcion`, `idmascota`, `idcliente`) VALUES
	('21463857', '25648134', '12345678'),
	('25498612', '32157898', '12345678');

DELIMITER //
CREATE PROCEDURE `AgregarCliente`(
  IN cliente_id VARCHAR(8),
  IN nombre VARCHAR(50),
  IN apellido VARCHAR(50),
  IN dni VARCHAR(50),
  IN telefono VARCHAR(20),
  IN email VARCHAR(50),
  IN tipo VARCHAR(50)
)
BEGIN
  INSERT INTO Cliente (idcliente, nombre, apellido, dni, telefono, email, tipo)
  VALUES (cliente_id, nombre, apellido, dni, telefono, email, tipo);
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `BuscarCliente`(
  IN cliente_id VARCHAR(8)
)
BEGIN
  SELECT *
  FROM Cliente
  WHERE idcliente = cliente_id;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `BuscarProducto`(
    IN p_idproducto VARCHAR(8)
)
BEGIN
    SELECT *
    FROM Producto
    WHERE idproducto = p_idproducto;
END//
DELIMITER ;

CREATE TABLE IF NOT EXISTS `cita` (
  `idcita` varchar(8) NOT NULL,
  `idcliente` varchar(8) DEFAULT NULL,
  `fecha_cita` date DEFAULT NULL,
  `razon_cita` varchar(255) DEFAULT NULL,
  `id_mascota` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`idcita`),
  KEY `idcliente` (`idcliente`),
  CONSTRAINT `cita_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `cliente` (
  `idcliente` varchar(8) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `apellido` varchar(50) DEFAULT NULL,
  `dni` varchar(50) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `cliente` (`idcliente`, `nombre`, `apellido`, `dni`, `telefono`, `email`, `tipo`) VALUES
	('12345678', 'Yahir', 'Vera', '73007573', '952249355', 'yahir-10@outlook.com', 'Guapo');

DELIMITER //
CREATE PROCEDURE `ComprarProducto`(
    IN p_idproducto VARCHAR(8),
    IN p_cantidad INT
)
BEGIN
    UPDATE Producto
    SET stock = stock - p_cantidad
    WHERE idproducto = p_idproducto;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `EliminarCliente`(
  IN cliente_id VARCHAR(8)
)
BEGIN
  DELETE FROM Cliente
  WHERE idcliente = cliente_id;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `EliminarProducto`(
    IN p_idproducto VARCHAR(8)
)
BEGIN
    DELETE FROM Producto
    WHERE idproducto = p_idproducto;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `IngresarMascota`(
    IN p_idmascota VARCHAR(8),
    IN p_raza VARCHAR(50),
    IN p_fecha_nacimiento DATE,
    IN p_cliente_idcliente VARCHAR(8),
    IN p_sexo VARCHAR(50)
)
BEGIN
    INSERT INTO Mascota(idmascota, raza, fecha_nacimiento, cliente_idcliente, sexo)
    VALUES (p_idmascota, p_raza, p_fecha_nacimiento, p_cliente_idcliente, p_sexo);
    SELECT 'Mascota ingresada correctamente' AS mensaje;
END//
DELIMITER ;

CREATE TABLE IF NOT EXISTS `mascota` (
  `idmascota` varchar(8) NOT NULL,
  `raza` varchar(50) DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `cliente_idcliente` varchar(8) DEFAULT NULL,
  `sexo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idmascota`),
  KEY `cliente_idcliente` (`cliente_idcliente`),
  CONSTRAINT `mascota_ibfk_1` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `mascota` (`idmascota`, `raza`, `fecha_nacimiento`, `cliente_idcliente`, `sexo`) VALUES
	('25648134', 'Boxer', '2022-10-10', NULL, 'M'),
	('26594876', 'Pitbull', '2017-10-11', NULL, 'F'),
	('32157898', 'chusco', '2020-10-10', '12345678', 'M'),
	('85216973', 'CHUSCO', '2015-10-10', NULL, 'M');

DELIMITER //
CREATE PROCEDURE `MostrarMascota`()
BEGIN
    SELECT *
    FROM Mascota;
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `MostrarProductos`()
BEGIN
    SELECT *
    FROM Producto;
END//
DELIMITER ;

CREATE TABLE IF NOT EXISTS `producto` (
  `idproducto` varchar(8) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` varchar(100) DEFAULT NULL,
  `marca` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `transaccion_idtransaccion` varchar(8) DEFAULT NULL,
  `cliente_idcliente` varchar(8) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  PRIMARY KEY (`idproducto`),
  KEY `transaccion_idtransaccion` (`transaccion_idtransaccion`),
  KEY `cliente_idcliente` (`cliente_idcliente`),
  CONSTRAINT `producto_ibfk_1` FOREIGN KEY (`transaccion_idtransaccion`) REFERENCES `transaccion` (`idtransaccion`),
  CONSTRAINT `producto_ibfk_2` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `producto` (`idproducto`, `nombre`, `descripcion`, `marca`, `precio`, `transaccion_idtransaccion`, `cliente_idcliente`, `stock`) VALUES
	('12345678', 'Juguete', 'Juguete para perro Mimascot', 'Mimascot', 50.00, NULL, NULL, 21),
	('15324876', 'Croquetas', 'altas en vitamina D', 'Mimascot', 150.00, NULL, NULL, 40),
	('98765432', 'Plancha', 'Plancha para pelaje de animal', 'Gab', 300.00, NULL, NULL, 49);

DELIMITER //
CREATE PROCEDURE `registrarMascota`(
    IN idMascota VARCHAR(8),
    IN raza VARCHAR(50),
    IN fechaNacimiento DATE,
    IN sexo VARCHAR(50)
)
BEGIN
    INSERT INTO Mascota (idmascota, raza, fecha_nacimiento, sexo)
    VALUES (idMascota, raza, fechaNacimiento, sexo);
END//
DELIMITER ;

DELIMITER //
CREATE PROCEDURE `RegistrarProducto`(
    IN p_idproducto VARCHAR(8),
    IN p_nombre VARCHAR(50),
    IN p_descripcion VARCHAR(100),
    IN p_marca VARCHAR(50),
    IN p_precio DECIMAL(10, 2),
    IN p_stock INT
)
BEGIN
    INSERT INTO Producto (idproducto, nombre, descripcion, marca, precio, stock)
    VALUES (p_idproducto, p_nombre, p_descripcion, p_marca, p_precio, p_stock);
END//
DELIMITER ;

CREATE TABLE IF NOT EXISTS `servicios` (
  `idservicios` varchar(8) NOT NULL,
  `tipo` varchar(50) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `cliente_idcliente` varchar(8) DEFAULT NULL,
  `transaccion_idtransaccion` varchar(8) DEFAULT NULL,
  `cita_idcita` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`idservicios`),
  KEY `cliente_idcliente` (`cliente_idcliente`),
  KEY `transaccion_idtransaccion` (`transaccion_idtransaccion`),
  KEY `cita_idcita` (`cita_idcita`),
  CONSTRAINT `servicios_ibfk_1` FOREIGN KEY (`cliente_idcliente`) REFERENCES `cliente` (`idcliente`),
  CONSTRAINT `servicios_ibfk_2` FOREIGN KEY (`transaccion_idtransaccion`) REFERENCES `transaccion` (`idtransaccion`),
  CONSTRAINT `servicios_ibfk_3` FOREIGN KEY (`cita_idcita`) REFERENCES `cita` (`idcita`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


CREATE TABLE IF NOT EXISTS `transaccion` (
  `idtransaccion` varchar(8) NOT NULL,
  `idcliente` varchar(8) DEFAULT NULL,
  `idproducto` varchar(8) DEFAULT NULL,
  `fecha_transaccion` date DEFAULT NULL,
  `metodo_pago` varchar(50) DEFAULT NULL,
  `total_compra` decimal(10,2) DEFAULT NULL,
  `detalles_envio` varchar(255) DEFAULT NULL,
  `estado_transaccion` varchar(50) DEFAULT NULL,
  `num_factura` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`idtransaccion`),
  KEY `idcliente` (`idcliente`),
  KEY `idproducto` (`idproducto`),
  CONSTRAINT `transaccion_ibfk_1` FOREIGN KEY (`idcliente`) REFERENCES `cliente` (`idcliente`),
  CONSTRAINT `transaccion_ibfk_2` FOREIGN KEY (`idproducto`) REFERENCES `producto` (`idproducto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
